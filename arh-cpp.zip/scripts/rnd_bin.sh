/bin/dd if=/dev/urandom of=rnd.bin bs=10 count=1
